from passlib.context import CryptContext
e =  CryptContext(['pbkdf2_sha512']).encrypt('Rock123')
#print(e)


# UPDATE res_users SET password='$pbkdf2-sha512$25000$ds65N8aYUwoBoDSmtFaqNQ$rP4PFjIy1IfGSFqvatt0LRXDHItOjMz0rtlJqIINXRcWBZ2g.6KhAHup1kDXvMpJElN66lZk7Kku5RnGahskcg' WHERE login='rockscripts@gmail.com'

from sunatservice.sunatservice import Service
import os
from zipfile import ZipFile
import base64
from lxml import etree

xmlPath = "/odoo_sunatperu/custom/addons/sunat_fact/models/xml"

SunatService = Service()
SunatService.setXMLPath(xmlPath)
SunatService.fileName = "10094637339-03-FC00-00000001"
SunatService.initSunatAPI("SANDBOX", "sendBill")
data = {
    "serie": "FC00",
    "numero": "00000001",
    "emisor": {
        "tipo_documento": "6",
        "nro": "10094637339",
        "nombre": "Bust\u00edos mu\u00f1oz gino gianpaolo",
        "direccion": "Av.santa rosa, mz f, lt.18 la florida - smp",
        "ciudad": "Lima",
        "ciudad_sector": "San martin de porres",
        "departamento": "Lima",
        "codigoPostal": "140126",
        "codigoPais": "PE",
        "ubigeo": "140126"
    },
    "receptor": {
        "tipo_documento": "6",
        "nro": "10407606359",
        "nombre": "Valentin flores gabriel",
        "direccion": "Av. elmer urb 200 millas",
        "ciudad": "Callao",
        "ciudad_sector": "Callao",
        "departamento": "CALLAO",
        "codigoPostal": "240101",
        "codigoPais": "PE",
        "ubigeo": "240101"
    },
    "fechaEmision": "2019-11-07",
    "fechaVencimiento": "2019-11-07",
    "horaEmision": "20:45:41",
    "subTotalVenta": 61.016949152542374,
    "totalVentaGravada": 72.0,
    "tipoMoneda": "PEN",
    "items": [
        {
            "id": "20",
            "cantidad": "8.0",
            "medidaCantidad": "NIU",
            "descripcion": "[001] TURRON JOEL EN CAJA 900G",
            "precioUnidad": 7.627118644067797,
            "tipoPrecioVentaUnitario": "01",
            "clasificacionProductoServicioCodigo": "73131906",
            "subTotalVenta": 61.016949152542374,
            "totalVenta": 72.0,
            "tributos": [
                {
                    "codigo": "1000",
                    "porcentaje": 18.0,
                    "tipo_calculo": "percent",
                    "montoAfectacionTributo": 10.983050847457626,
                    "total_venta": 61.016949152542374,
                    "tipoAfectacionTributoIGV": "10",
                    "sistemaCalculoISC": "01"
                }
            ]
        }
    ],
    "tributos": {
        "1000": [
            {
                "codigo": "1000",
                "total_venta": 61.016949152542374,
                "porcentaje": 18.0,
                "sumatoria": 10.983050847457626,
                "tipo_calculo": "percent"
            }
        ]
    },
    "sunat_sol": {
        "ruc": "10094637339",
        "usuario": "10094637339IANSONNE",
        "clave": "ogradvine",
        "certificado": {
            "crt": "rsacert.pem",
            "key": "rsakey.pem",
            "pass": "2020gino2020"
        }
    },
    "accion": "fill_submit",
    "licencia": "081OHTGAVHJZ4GOZJGJV"
}

response = SunatService.getCDR(data,"07")
print(response)