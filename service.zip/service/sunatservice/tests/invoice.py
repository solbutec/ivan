from sunatservice.sunatservice import Service
import os
from zipfile import ZipFile
import base64
from lxml import etree

xmlPath = "/odooPeruTest/custom/addons/sunat_fact/models/xml"

SunatService = Service()
#response = SunatService.consultRUC(20347268683)
#print(response)

#SunatService.setXMLPath(xmlPath)
#SunatService.fileName = "20603408111-01-F001-00000009"
#SunatService.initSunatAPI("SANDBOX", "sendBill")
#SunatService = Service()

SunatService.setXMLPath(xmlPath)
SunatService.fileName = "20601734533-01-F001-00000019"
SunatService.initSunatAPI("SANDBOX", "sendBill")
sunat_data = {
            "serie":"F001",
            "numero":"00000019",
            "emisor":{
            "tipo_documento":"6",
            "nro":"20601734533",
            "nombre":"TRAVESIAS GASTRONOMICAS S.A.C.",
            "direccion":"JR. NARCISO DE LA COLINA NRO. 911 URB. CERCADO LIMA",
            "ciudad":"LIMA",
            "ciudad_sector":"False",
            "departamento":"Lima",
            "codigoPostal":"78945",
            "codigoPais":"PE",
            "ubigeo":"150204"
            },
            "receptor":{
            "tipo_documento":"6",
            "nro":"20432940161",
            "nombre":"VETERQUIMICA PERU S.A.C.",
            "direccion":"AV. HUAROCHIRI S/N MZA. E LOTE. 20 URB. SANTA RAQUEL 3 ET (ESQ CON AV ARBOLEDA CON HUAROCHIRI) LIMA",
            "ciudad":"LIMA",
            "ciudad_sector":"False",
            "departamento":"Lima",
            "codigoPostal":"78945",
            "codigoPais":"PE"
            },
            "fechaEmision":"2019-06-12",
            "fechaVencimiento":"2019-06-12",
            "horaEmision":"19:37:50",
            "totalVenta":160.0,
            "totalVentaGravada":188.8,
            "tipoMoneda":"PEN",
            "items":[
            {
            "id":"69",
            "cantidad":"1.0",
            "medidaCantidad":"ZZ",
            "descripcion":"[U08] SmartWatch",
            "precioUnidad":160.0,
            "tipoPrecioVentaUnitario":"01",
            "subTotalVenta":160.0,
            "totalVenta":188.8,
            "tributos":[
            {
            "codigo":"1000",
            "porcentaje":18,
            "montoAfectacionTributo":28.8,
            "total_venta":160.0,
            "tipoAfectacionTributoIGV":"10",
            "sistemaCalculoISC":"01"
            }
            ]
            }
            ],
            "tributos":{
            "1000":[
            {
            "codigo":"1000",
            "total_venta":160.0,
            "porcentaje":18,
            "sumatoria":28.8
            }
            ]
            },
            "sunat_sol":{
            "ruc":"20603408111",
            "usuario":"20603408111MODDATOS",
            "clave":"moddatos"
            },
            "accion":"fill_submit",
            "licencia":"081OHTGAVHJZ4GOZJGJV"
            }
SunatResponse = SunatService.processInvoice(sunat_data)
print(SunatResponse)